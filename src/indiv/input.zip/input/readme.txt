1. git clone https://github.com/UAntwerpen/fase1....git
2. kopieer de inputbestanden van BB in je root map
3. zorg dat het werkt. De output komt gewoon in je root map.
4. run ./todot.sh
5. zorg dat je in je root map staat
6. git config user.email "voornaam.achternaam@uantwerpen.be"
7. git config user.name "Voornaam Achternaam"
8. git add .
9. git commit -m "verdediging"
10. git push origin master